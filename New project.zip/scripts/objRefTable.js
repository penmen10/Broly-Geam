const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Keyboard,
		C3.Plugins.TiledBg,
		C3.Behaviors.solid,
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Behaviors.shadowcaster,
		C3.Behaviors.Bullet,
		C3.Plugins.Keyboard.Cnds.OnKey,
		C3.Plugins.Sprite.Acts.Spawn,
		C3.Plugins.Sprite.Exps.AllChildCount,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.Destroy
	];
};
self.C3_JsPropNameTable = [
	{Keyboard: 0},
	{Solid: 0},
	{TiledBackground: 0},
	{Platform: 0},
	{ScrollTo: 0},
	{ShadowCaster: 0},
	{Sprite: 0},
	{Bullet: 0},
	{Sprite2: 0},
	{Sprite3: 0},
	{TiledBackground2: 0}
];

self.InstanceType = {
	Keyboard: class extends self.IInstance {},
	TiledBackground: class extends self.ITiledBackgroundInstance {},
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	TiledBackground2: class extends self.ITiledBackgroundInstance {}
}